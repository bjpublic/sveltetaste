<script>
  let innerWidth, innerHeight, outerWidth, outerHeight, scrollX, scrollY, online;
</script>

<svelte:window
  bind:innerWidth
  bind:innerHeight
  bind:outerWidth
  bind:outerHeight
  bind:scrollX
  bind:scrollY
  bind:online
/>
<div>
  <p>innerWidth: {innerWidth}</p>
  <p>innerHeight: {innerHeight}</p>
  <p>outerWidth: {outerWidth}</p>
  <p>outerHeight: {outerHeight}</p>
  <p>scrollX: {scrollX}</p>
  <p>scrollY: {scrollY}</p>
  <p>online: {online}</p>
  <button on:click={() => scrollY = 100}>scrollY = 100</button>
</div>

<style>
  div {
    height: 200vh;
  }
</style>