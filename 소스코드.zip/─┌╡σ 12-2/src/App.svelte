<script>
  import { fade } from 'svelte/transition';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div transition:fade={{ duration: 1000 }}>
    Fades in and out
  </div>
{/if}