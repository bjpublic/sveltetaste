<script>
  import { fade } from 'svelte/transition';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div transition:fade="{{delay: 250, duration: 300}}">
    fades in and out
  </div>
{/if}