<script>
  import { fade, fly } from 'svelte/transition';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div in:fly="{{ y: 200, duration: 2000 }}" out:fade>
    Flies in, fades out
  </div>
{/if}