<!-- src/Box.svelte -->
<div>
  <slot></slot>
</div>