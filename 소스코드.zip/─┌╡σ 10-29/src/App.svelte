<!-- src/App.svelte -->
<script>
  import { get } from 'svelte/store';
  import { time } from './stores.js';

  const formatter = new Intl.DateTimeFormat('en', {
    hour12: true,
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit'
  });
</script>

<p>{formatter.format($time)}</p>
<p>{formatter.format(get(time))}</p>