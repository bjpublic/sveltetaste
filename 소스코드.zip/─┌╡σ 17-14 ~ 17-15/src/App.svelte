<!-- src/App.svelte -->
<script>
  import Post from './Post.svelte';

  let posts = [
    { id: 1, contents: '기초 문법', isGood: false },
    { id: 2, contents: '심화 문법', isGood: false },
    { id: 3, contents: '컴파일 옵션', isGood: false },
  ];

  function toggle (toggled) {
    posts = posts.map(post => {
      if (post === toggled) {
        return { ...post, isGood: !post.isGood };
      } else {
        return post;
      }
    });
  }
</script>

{#each posts as post (post.id)}
  <Post data={post} on:click={() => toggle(post)}/>
{/each}