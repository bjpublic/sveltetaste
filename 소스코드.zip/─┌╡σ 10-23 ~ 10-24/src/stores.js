// src/stores.js
import { writable, derived } from 'svelte/store';

export const num1 = writable(0);
export const num2 = writable(2);
export const multiple = derived([num1, num2], ([$num1, $num2]) => $num1 * $num2);