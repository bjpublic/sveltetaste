// src/stores.js
import { writable, derived } from 'svelte/store';

export const count = writable(0);
export const doubled = derived(count, ($count, set) => {
  const interval = setTimeout(() => set($count * 2), 1000);
  return () => {
    clearInterval(interval);
  };
}, '1초 후 값이 반영됩니다.');