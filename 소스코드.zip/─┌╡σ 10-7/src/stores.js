// src/stores.js
import { writable } from 'svelte/store';

export const count = writable(0, (set) => {
  // set 함수를 사용하여 count 스토어의 값을 업데이트 할 수 있습니다.
  console.log('count 스토어 감시를 시작합니다.');
  return () => console.log('count 스토어 감시가 종료됩니다.');
});