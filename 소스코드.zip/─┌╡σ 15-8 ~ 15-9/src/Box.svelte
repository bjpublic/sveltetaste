<!-- src/Box.svelte -->
<!-- $$slots는 { title: true, default: true }입니다. -->
<div>
  <slot name="title"></slot>
  {#if $$slots.description}
    <hr />
    <slot name="description"></slot>
  {/if}
  <slot></slot>
</div>