<!-- src/Box.svelte -->
<div>
  <slot>
    <em>기본 값입니다.</em>
  </slot>
</div>