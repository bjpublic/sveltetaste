<script>
  let isEnter;
</script>

<svelte:body
  on:mouseenter={() => isEnter = true}
  on:mouseleave={() => isEnter = false}
/>

{isEnter ? 'enter' : 'leave'}