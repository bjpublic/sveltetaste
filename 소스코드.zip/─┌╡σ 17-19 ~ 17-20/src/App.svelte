<!-- src/App.svelte -->
<script>
  import Accessible from './Accessible.svelte';
  let accessibleComponent;
</script>

<Accessible bind:this={accessibleComponent} />

<button on:click="{() => console.log(accessibleComponent.getText())}">데이터 접근하기</button>