<!-- src/Updater.svelte -->
<script>
  import { count } from './stores';

  export let num;
  export let text;

  function handleUpdate () {
    $count += num;
  }
</script>

<button on:click="{handleUpdate}">{text}</button>