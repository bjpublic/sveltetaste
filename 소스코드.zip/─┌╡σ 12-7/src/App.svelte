<script>
  import { slide } from 'svelte/transition';
  import { quintOut } from 'svelte/easing';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div transition:slide="{{delay: 250, duration: 300, easing: quintOut }}">
    slides in and out
  </div>
{/if}