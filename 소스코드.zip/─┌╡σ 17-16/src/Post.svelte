<!-- src/Post.svelte -->
<svelte:options immutable />

<script>
  import { afterUpdate } from 'svelte';

  export let data;

  let updateCount = 0;
  afterUpdate(() => {
    updateCount++;
  })
</script>

<div on:click>{data.contents} ({updateCount})</div>