<!-- src/App.svelte -->
<script>
  import Context from './Context.svelte';
</script>

<Context name="첫번째 콘텍스트" />
<Context name="두번째 콘텍스트" />