<script>
  import { spring } from 'svelte/motion';

  let size = spring(10);
</script>

<style>
  svg { width: 100%; height: 100% }
  circle { fill: #ff3e00 }
</style>

<svg
  on:mousedown="{() => size.set(30, { hard: true })}"
  on:mouseup="{async () => {
    await size.set(10);
    alert('반영 완료!');
  }}"
>
  <circle cx={100} cy={100} r={$size}/>
</svg>