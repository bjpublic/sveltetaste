<!-- src/App.svelte -->
<script>
  import { num1, num2, multiple } from './stores';
</script>

<input bind:value="{$num1}"/>
<input bind:value="{$num2}"/>
<p>{$num1} X {$num2} = {$multiple}</p>