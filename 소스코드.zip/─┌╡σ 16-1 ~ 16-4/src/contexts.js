// src/contexts.js
export const textKey = 'text';