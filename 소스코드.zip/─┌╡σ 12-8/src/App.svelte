<script>
  import { scale } from 'svelte/transition';
  import { quintOut } from 'svelte/easing';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div transition:scale="{{duration: 500, delay: 500, opacity: 0.5, start: 0.5, easing: quintOut}}">
    scales in and out
  </div>
{/if}