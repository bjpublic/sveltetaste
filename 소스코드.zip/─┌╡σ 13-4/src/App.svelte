<script>
  import { cubicInOut } from 'svelte/easing';

  let uid = 1;
  let array = [
    { id: uid++, text: '테스트 문자열' },
  ];

  function whizz(node, { from, to }, params) {
    const dx = from.left - to.left;
    const dy = from.top - to.top;

    const d = Math.sqrt(dx * dx + dy * dy);

    return {
      delay: 0,
      duration: Math.sqrt(d) * 120,
      easing: cubicInOut,
      css: (t, u) =>
        `transform: translate(${u * dx}px, ${u * dy}px) rotate(${t*360}deg);`
    };
  }

  function add(input) {
    const item = { id: uid++, text: input.value };
    array = [item, ...array];
  }
</script>

<input
  placeholder="문자열을 입력해 주세요."
  on:keydown={e => e.which === 13 && add(e.target)}
>
<ul>
  {#each array as item (item.id)}
    <li
      animate:whizz
    >{item.text}</li>
  {/each}
</ul>