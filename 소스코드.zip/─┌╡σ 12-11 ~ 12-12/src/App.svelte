<!-- src/App.svelte -->
<script>
  import { quintOut } from 'svelte/easing';
  import { crossfade } from 'svelte/transition';
  import './style.css';

  const [send, receive] = crossfade({
    duration: d => Math.sqrt(d * 200),

    fallback(node, params) {
      const style = getComputedStyle(node);
      const transform = style.transform === 'none' ? '' : style.transform;

      return {
        duration: 600,
        easing: quintOut,
        css: t => `
          transform: ${transform} scale(${t});
          opacity: ${t}
        `
      };
    }
  });

  let uid = 1;

  let todos = [
    { id: uid++, done: false, description: 'Svelte 공부하기' },
    { id: uid++, done: false, description: '책 읽기' },
    { id: uid++, done: true,  description: '버그 수정하기' },
  ];

  function add(input) {
    const todo = {
      id: uid++,
      done: false,
      description: input.value
    };

    todos = [todo, ...todos];
    input.value = '';
  }

  function remove(todo) {
    todos = todos.filter(t => t !== todo);
  }

  function mark(todo, done) {
    todo.done = done;
    remove(todo);
    todos = todos.concat(todo);
  }
</script>

<div class='board'>
  <input
    placeholder="해야 할 일을 입력해 주세요."
    on:keydown={e => e.key === 'Enter' && add(e.target)}
  >

  <div class='left'>
    <h2>todo</h2>
    {#each todos.filter(t => !t.done) as todo (todo.id)}
      <label
        in:receive="{{key: todo.id}}"
        out:send="{{key: todo.id}}"
      >
        <input type=checkbox on:change={() => mark(todo, true)}>
        {todo.description}
        <button on:click="{() => remove(todo)}">remove</button>
      </label>
    {/each}
  </div>

  <div class='right'>
    <h2>done</h2>
    {#each todos.filter(t => t.done) as todo (todo.id)}
      <label
        class="done"
        in:receive="{{key: todo.id}}"
        out:send="{{key: todo.id}}"
      >
        <input type=checkbox checked on:change={() => mark(todo, false)}>
        {todo.description}
        <button on:click="{() => remove(todo)}">remove</button>
      </label>
    {/each}
  </div>
</div>
