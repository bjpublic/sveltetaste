<!-- src/App.svelte -->
<script>
  import Box from './Box.svelte';
</script>

<Box>
  <p>Box 컴포넌트의 하위 요소입니다.</p>
</Box>

<Box/>