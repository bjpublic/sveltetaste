<!-- src/App.svelte -->
<script>
  import { count, doubled } from './stores';
</script>

<input bind:value="{$count}"/>
<p>{$count} X 2 = {$doubled}</p>