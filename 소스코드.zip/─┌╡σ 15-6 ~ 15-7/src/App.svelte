<!-- src/App.svelte -->
<script>
  import Box from './Box.svelte';
</script>

<Box>
  <p slot="description">Box 컴포넌트의 하위 요소입니다.</p>
  <h1 slot="title">주제!</h1>
</Box>