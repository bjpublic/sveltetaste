<!-- src/Setter.svelte -->
<script>
  import { count } from './stores';

  export let num;
  export let text;

  function handleSet () {
    count.set(num);
  }
</script>

<button on:click="{handleSet}">{text}</button>