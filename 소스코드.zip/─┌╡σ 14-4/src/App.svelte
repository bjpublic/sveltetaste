<script>
  let delay = 1000;

  function focus (node, { delay } = { delay: 0 }) {
    let id = setTimeout(() => node.focus(), delay);
    return {
      update ({ delay }) {
        clearTimeout(id);
        id = setTimeout(() => node.focus(), delay);
      },
      destroy () {
        clearTimeout(id);
      },
    };
  }
</script>

<input type="range" min="0" max="5000" step="1000" bind:value="{delay}" >
<input
  use:focus={{ delay }}
>