<!-- src/App.svelte -->
<script>
  import Box from './Box.svelte';
</script>

<Box>
  <h1 slot="title">주제!</h1>
  <div>Beomy 씀.</div>
</Box>