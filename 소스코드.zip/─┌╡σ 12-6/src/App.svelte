<script>
  import { fly } from 'svelte/transition';
  import { quintOut } from 'svelte/easing';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div transition:fly="{{delay: 250, duration: 300, x: 100, y: 500, opacity: 0.5, easing: quintOut}}">
    flies in and out
  </div>
{/if}