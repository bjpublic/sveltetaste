<!-- src/App.svelte -->
<script>
  import { count } from './stores';
  import Updater from './Updater.svelte';
  import Setter from './Setter.svelte';

  let viewCount;

  count.subscribe(value => {
    console.log(111)
    viewCount = value;
  });
</script>

<p>{viewCount}</p>
<div>
  <Updater num="{1}" text="+" />
  <Updater num="{-1}" text="-" />
  <Setter num="{0}" text="reset"/>
</div>