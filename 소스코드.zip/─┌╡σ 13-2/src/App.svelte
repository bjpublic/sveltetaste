<script>
  import { flip } from 'svelte/animate';
  import { cubicInOut } from 'svelte/easing';

  let uid = 1;
  let array = [
    { id: uid++, text: '테스트 문자열' },
  ];

  function add(input) {
    const item = { id: uid++, text: input.value };
    array = [item, ...array];
  }
</script>

<input
  placeholder="문자열을 입력해 주세요."
  on:keydown={e => e.which === 13 && add(e.target)}
>
<ul>
  {#each array as item (item.id)}
    <li
      animate:flip={{ delay: 300, duration: 500, easing: cubicInOut }}
    >{item.text}</li>
  {/each}
</ul>