<!-- src/App.svelte -->
<script>
  import FancyList from './FancyList.svelte';
  let items = [
    { text: '책가방' },
    { text: '공책' },
    { text: '연필' },
  ]
</script>

<FancyList {items} let:prop={thing} let:length>
  <div slot="item">{thing.text}</div> <!-- item 슬롯에서 length는 undefined 입니다. -->
  <p slot="footer">길이: {length}</p> <!-- footer 슬롯에서 thing는 undefined 입니다. -->
</FancyList>