<!-- src/Updater.svelte -->
<script>
  import { count } from './stores';

  export let num;
  export let text;

  function handleUpdate () {
    count.update(n => n + num);
  }
</script>

<button on:click="{handleUpdate}">{text}</button>