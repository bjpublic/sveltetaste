<script>
  import { fade } from 'svelte/transition';
  let x = true;
  let y = true;
</script>

<label><input type="checkbox" bind:checked={x}>x</label>
<label><input type="checkbox" bind:checked={y}>y</label>

{#if x}
  {#if y}
    <p transition:fade>
      fades in and out when x or y change
    </p>

    <p transition:fade|local>
      fades in and out only when y changes
    </p>
  {/if}
{/if}