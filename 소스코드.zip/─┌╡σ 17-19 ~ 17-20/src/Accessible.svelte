<!-- src/Accessible.svelte -->
<svelte:options accessors />

<script>
  let text = '접근이 허용되었습니다.';
  export function getText () {
    return text;
  }
</script>

<div>{text}</div>