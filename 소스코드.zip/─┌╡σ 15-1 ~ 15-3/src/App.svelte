<script>
	import Box from './Box.svelte';
</script>

<div>
  <p>div의 하위 요소입니다.</p>
</div>

<Box>
  <p>Box 컴포넌트의 하위 요소입니다.</p>
</Box>