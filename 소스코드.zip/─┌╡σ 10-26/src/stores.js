// src/stores.js
import { writable, derived } from 'svelte/store';

export const num1 = writable(0);
export const num2 = writable(2);
export const multiple = derived([num1, num2], ([$num1, $num2], set) => {
  const interval = setTimeout(() => set($num1 * $num2), 1000);
  return () => {
    clearInterval(interval);
  };
}, '1초 후 값이 반영됩니다.');