<script>
  function focus (node) {
    node.focus();
  }
</script>

<input
  use:focus
>