<!-- src/Box.svelte -->
<div>
  <slot name="title"></slot>
  <hr />
  <slot name="description"></slot>
</div>