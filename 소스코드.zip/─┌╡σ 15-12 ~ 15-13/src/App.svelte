<!-- src/App.svelte -->
<script>
  import FancyList from './FancyList.svelte';
  let items = [
    { text: '책가방' },
    { text: '공책' },
    { text: '연필' },
  ]
</script>

<FancyList {items}>
  <div slot="item" let:prop={thing}>{thing.text}</div>
</FancyList>