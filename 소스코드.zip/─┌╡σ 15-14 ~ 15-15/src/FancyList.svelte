<!-- src/FancyList.svelte -->
<script>
  export let items;
</script>
<ul>
  {#each items as item}
    <li class="fancy">
      <slot name="item" prop={item}></slot>
    </li>
  {/each}
</ul>
<slot name="footer" length={items.length}></slot>