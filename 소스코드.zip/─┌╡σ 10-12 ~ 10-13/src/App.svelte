<!-- src/App.svelte -->
<script>
  import { count } from './stores';
</script>

<input bind:value="{$count}"/>
<p>{$count}</p>