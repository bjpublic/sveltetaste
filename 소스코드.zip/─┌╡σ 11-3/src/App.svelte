<script>
  import { tweened } from 'svelte/motion';
  import { cubicOut } from 'svelte/easing';

  const progress = tweened(0, {
    duration: 400,
    easing: cubicOut
  });

  async function handleSet(value, options) {
    await progress.set(value, options);
    alert('반영 완료!');
  }
</script>

<style>
  progress {
    display: block;
    width: 100%;
  }
</style>

<progress value={$progress}></progress>

<button on:click="{() => handleSet(0, { duration: 1000 })}">0%</button>
<button on:click="{() => handleSet(0.25, { duration: 2000 })}">25%</button>
<button on:click="{() => handleSet(0.5, { duration: 3000 })}">50%</button>
<button on:click="{() => handleSet(0.75, { duration: 4000 })}">75%</button>
<button on:click="{() => handleSet(1, { duration: 5000 })}">100%</button>