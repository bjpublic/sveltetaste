<script>
  import { blur } from 'svelte/transition';
  let condition = true;
</script>

<label>
  <input type="checkbox" bind:checked={condition}>
  상태 변경
</label>

{#if condition}
  <div transition:blur="{{amount: 10}}">
    blurs in and out
  </div>
{/if}